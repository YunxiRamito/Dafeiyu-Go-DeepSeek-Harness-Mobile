# Dafeiyu-Go Connect Plugin

Dafeiyu-Go / DSH-Aries 的设备连接扩展插件。它只使用启动器提供的高层 `ConnectionProvider`，为已经完成配对的当前小组提供工作区同步和 DSH 网页广播能力。

当前 0.2.0 默认关闭同步和广播，已接入 PC named pipe 和 Android bridge transport。没有可用 endpoint 或注入 provider 时返回 `waiting_for_launcher` / `launcher_unavailable`，不会伪造连接状态、远端在线状态或同步成功。

## 目录

- `src/framework/`：插件配置、权限、IPC envelope、Provider 契约、命令注册和错误状态。
- `src/sync/`：工作区路径过滤、敏感文件拒绝、哈希、分块/断点续传、队列、冲突和缓存清理。
- `src/broadcast/`：网页 URL 脱敏、payload 安全检查、发送/接收去重和通知控制。
- `docs/contract.md`：启动器 IPC/ConnectionProvider 契约和必需方法。
- `docs/sync-protocol.md`：工作区同步协议。
- `docs/broadcast-protocol.md`：网页广播协议。
- `docs/cache-cleanup.md`：文件缓存清理行为。
- `docs/security.md`：权限边界和安全约束。`docs/integration-status.md`：Aries 服务端和本地 Provider 集成状态。

## 开发与验证

需要 Node.js 22.6 或更高版本。项目不依赖 npm 网络安装；测试使用 Node 内置 test runner 和 TypeScript strip-types 支持。

```powershell
npm test
npm run check
node --experimental-strip-types --test tests/framework/*.test.ts tests/sync/*.test.ts tests/broadcast/*.test.mjs
```

所有测试输出和隔离安装目录都在仓库 `Temp/` 下。插件不保存 Aries 私钥、内容密钥、token 或 cookie；同步仅写入用户显式选择的工作区。

## DSH 插件安装

`package.json` 使用 DSH profile bundle 的 `cordis.patch.yml` 入口；`lib/` 是从 `src/` 生成的零依赖运行时副本。插件本身不会创建设备身份、调用 Aries 原始 HTTP 管理 API 或实现配对流程。PC 自动发现安全 IPC；Android 由宿主注入 bridge 启动环境或高层 Provider。实际命令入口是 `/connection`。

详细边界和必需 IPC 方法见 [docs/contract.md](docs/contract.md)。

